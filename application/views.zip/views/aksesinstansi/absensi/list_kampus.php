<style>
    .th-middle {
        vertical-align: middle !important;
        text-align: center;
    }

    .nowrap th,
    .nowrap>tbody>tr>td {
        white-space: nowrap !important;
    }
</style>

<table id="table-absensi-kampus" class="table table-striped table-bordered table-responsive dt-responsive nowrap" style="width:100%">
    <thead>
        <tr>
            <th rowspan="2" class="th-middle">No</th>
            <th rowspan="2" class="th-middle">Lokasi</th>
            <th rowspan="2" class="th-middle">Tgl. Absensi</th>
            <th rowspan="2" class="th-middle" style="width: 100px;">Total Taruna Pria</th>
            <th rowspan="2" class="th-middle" style="width: 100px;">Total Taruna Wanita</th>
            <th colspan="3" class="text-center">Taruna Pria</th>
            <th colspan="3" class="text-center">Taruna Wanita </th>
            <th rowspan="2" class="th-middle">Action</th>
        </tr>
        <tr>
            <th class="text-center" style="width: 60px;">Sehat</th>
            <th class="text-center" style="width: 60px;">Terpapar</th>
            <th class="text-center" style="width: 60px;">Sakit/Ijin</th>
            <th class="text-center" style="width: 60px;">Sehat</th>
            <th class="text-center" style="width: 60px;">Terpapar</th>
            <th class="text-center" style="width: 60px;">Sakit/Ijin</th>
        </tr>
    </thead>
</table>