<style>
    .th-middle {
        vertical-align: middle !important;
        text-align: center;
    }

    .nowrap th,
    .nowrap>tbody>tr>td {
        white-space: nowrap !important;
    }
</style>

<table id="table-absensi-kantor" class="table table-striped table-bordered table-responsive dt-responsive nowrap" style="width:100%">
    <thead>
        <th width="80px">No</th>
        <th>Tgl. Absensi</th>
        <th>Tipe Pegawai</th>
        <th>Jumlah Pegawai</th>
        <th>Pegawai Sehat</th>
        <th>Pegawai Terpapar</th>
        <th>Pegawai Sakit/Ijin</th>
        <th>WFO</th>
        <th>WFH</th>
        <th>Dinas Luar</th>
        <th>Cuti</th>
        <th>Isoman</th>
        <th>Dirawat</th>
        <th>Vaksin 1</th>
        <th>Vaksin 2</th>
        <th>Vaksin Lain</th>
        <th>Action</th>
    </thead>
</table>